import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { ChatProvider } from '@/context/ChatContext';
import OnyxAssistant from '@/components/OnyxAssistant';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });

export const metadata: Metadata = {
  title: 'Razor-MCP Console',
  description:
    'Autonomous agentic commerce gateway — guardrailed agent spending, OTP escalation, active revenue recovery, and a live audit trail. Razorpay TEST MODE only.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="min-h-screen font-sans">
        {/* ChatProvider owns sessionId/agentId + the shared send() — mounted
            globally so the OnyxAssistant widget and the ChatPanel submit
            through ONE path. */}
        <ChatProvider>
          {children}
          {/* Onyx onboarding widget, mounted globally per spec. */}
          <OnyxAssistant />
        </ChatProvider>
      </body>
    </html>
  );
}
