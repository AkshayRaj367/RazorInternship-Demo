/**
 * Razor-MCP Console — split view: Onyx chat (left) + live RazorSense audit
 * dashboard (right), with the OTP gate and recovery banner as overlays.
 */
'use client';

import { useEffect } from 'react';
import ChatPanel from '@/components/ChatPanel';
import AuditTimeline from '@/components/AuditTimeline';
import WalletBadge from '@/components/WalletBadge';
import OTPModal from '@/components/OTPModal';
import RecoveryBanner from '@/components/RecoveryBanner';
import { useChat } from '@/context/ChatContext';
import { useSocket } from '@/hooks/useSocket';
import { useAuditStore } from '@/store/auditStore';

export default function Home() {
  const { sessionId } = useChat();
  const setAuditSession = useAuditStore((s) => s.setSession);
  const socketStatus = useSocket(sessionId || null);

  // Bind the audit store to the active session (localStorage key switch).
  useEffect(() => {
    if (sessionId) setAuditSession(sessionId);
  }, [sessionId, setAuditSession]);

  return (
    <div className="flex min-h-screen flex-col">
      <RecoveryBanner />

      <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/15 font-mono text-sm font-black text-emerald-400">
              RZ
            </div>
            <div className="leading-tight">
              <h1 className="text-base font-bold tracking-tight text-slate-100">
                Razor-MCP <span className="font-normal text-slate-500">Console</span>
              </h1>
              <p className="text-[11px] text-slate-500">
                autonomous agentic commerce · Razorpay <span className="text-amber-400/90">TEST MODE</span> — no real funds
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {sessionId && (
              <span
                className="hidden max-w-[160px] truncate rounded-lg border border-slate-700/70 bg-slate-900/80 px-2.5 py-1.5 font-mono text-[10px] text-slate-500 md:inline-block"
                title={sessionId}
              >
                session {sessionId.slice(0, 13)}…
              </span>
            )}
            <WalletBadge />
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6">
        <div className="grid gap-6 lg:grid-cols-2">
          <ChatPanel />
          <AuditTimeline status={socketStatus} />
        </div>
      </main>

      <footer className="border-t border-slate-800/80 px-4 py-4 sm:px-6">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600">
          <span>
            guardrail enforcement: <span className="font-mono text-slate-500">wallet_service.py</span> (atomic OCC debit)
          </span>
          <span>idempotent transactions · webhook dedupe · TTL-bounded recovery · capped chat memory</span>
        </div>
      </footer>

      <OTPModal />
    </div>
  );
}
