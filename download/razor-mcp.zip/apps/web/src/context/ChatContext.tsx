/**
 * ChatContext — owns sessionId/agentId and the ONE send() function.
 *
 * The OnyxAssistant quick-start pills and the ChatPanel manual input box both
 * submit through this exact send() — no duplicated chat-submission logic.
 */
'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { postJson, getJson } from '@/lib/apiClient';
import { useUiStore } from '@/store/auditStore';

export interface ToolCallRecord {
  name: string;
  arguments: Record<string, unknown>;
  result: Record<string, unknown>;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  toolCalls?: ToolCallRecord[];
  timestamp: string;
  error?: boolean;
}

export const ONBOARDING_FLAG = 'hasSeenOnboarding';
const SESSION_FLAG = 'razor-mcp-sessionId';
export const DEFAULT_AGENT_ID = 'onyx-agent';

interface ChatContextValue {
  sessionId: string;
  agentId: string;
  messages: ChatMessage[];
  loading: boolean;
  hasSeenOnboarding: boolean;
  markOnboardingSeen: () => void;
  send: (message: string) => Promise<void>;
}

const ChatContext = createContext<ChatContextValue | null>(null);

interface ChatApiResponse {
  reply: string;
  toolCalls?: ToolCallRecord[];
}

interface HistoryResponse {
  messages: Array<{ role: string; content: string; timestamp?: string; toolName?: string }>;
}

function readSessionId(): string {
  if (typeof window === 'undefined') return '';
  try {
    const existing = window.localStorage.getItem(SESSION_FLAG);
    if (existing && /^[A-Za-z0-9._:-]{6,128}$/.test(existing)) return existing;
    const fresh = crypto.randomUUID();
    window.localStorage.setItem(SESSION_FLAG, fresh);
    return fresh;
  } catch {
    return crypto.randomUUID();
  }
}

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [sessionId, setSessionId] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [hasSeenOnboarding, setHasSeenOnboarding] = useState(true); // server-safe default
  const mounted = useRef(false);

  useEffect(() => {
    if (mounted.current) return;
    mounted.current = true;
    const sid = readSessionId();
    setSessionId(sid);
    try {
      setHasSeenOnboarding(window.localStorage.getItem(ONBOARDING_FLAG) === 'true');
    } catch {
      setHasSeenOnboarding(false);
    }
    // Refresh-proof chat: restore the capped, isolated history for this session.
    getJson<HistoryResponse>(`/api/agent/conversation/${encodeURIComponent(sid)}`)
      .then((res) => {
        const restored: ChatMessage[] = (res.messages ?? [])
          .filter((m) => m.role === 'user' || m.role === 'assistant')
          .map((m, i) => ({
            id: `hist-${i}`,
            role: m.role as 'user' | 'assistant',
            content: m.content ?? '',
            timestamp: m.timestamp ?? new Date().toISOString(),
          }));
        if (restored.length > 0) setMessages(restored);
      })
      .catch(() => undefined);
  }, []);

  const markOnboardingSeen = useCallback(() => {
    setHasSeenOnboarding(true);
    try {
      window.localStorage.setItem(ONBOARDING_FLAG, 'true');
    } catch {
      /* private mode */
    }
  }, []);

  const send = useCallback(
    async (message: string) => {
      const trimmed = message.trim();
      if (!trimmed || loading || !sessionId) return;
      markOnboardingSeen(); // first message sent -> onboarding is done

      const userMsg: ChatMessage = {
        id: `u-${Date.now()}`,
        role: 'user',
        content: trimmed,
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, userMsg]);
      setLoading(true);
      try {
        const res = await postJson<ChatApiResponse>('/api/agent/chat', {
          prompt: trimmed,
          sessionId,
          agentId: DEFAULT_AGENT_ID,
        });
        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now()}`,
            role: 'assistant',
            content: res.reply ?? '(empty reply)',
            toolCalls: res.toolCalls ?? [],
            timestamp: new Date().toISOString(),
          },
        ]);
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'chat request failed';
        setMessages((prev) => [
          ...prev,
          {
            id: `a-${Date.now()}`,
            role: 'assistant',
            content: `I couldn't reach the agent-service (${msg}). The audit trail below still shows any recorded intent.`,
            timestamp: new Date().toISOString(),
            error: true,
          },
        ]);
      } finally {
        setLoading(false);
        useUiStore.getState().bumpWallet(); // refresh the badge after any spend
      }
    },
    [loading, sessionId, markOnboardingSeen]
  );

  const value = useMemo<ChatContextValue>(
    () => ({ sessionId, agentId: DEFAULT_AGENT_ID, messages, loading, hasSeenOnboarding, markOnboardingSeen, send }),
    [sessionId, messages, loading, hasSeenOnboarding, markOnboardingSeen, send]
  );

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
}

export function useChat(): ChatContextValue {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error('useChat must be used inside <ChatProvider>');
  return ctx;
}
