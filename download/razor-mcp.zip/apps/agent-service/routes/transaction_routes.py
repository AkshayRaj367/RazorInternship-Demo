"""Transaction endpoints — the money-movement API.

Every write goes through the same guardrailed engine as Onyx:
  POST /api/transactions/execute       @require_idempotency_key (reusable decorator)
  POST /api/transactions/<id>/verify-otp   the human approval gate
  GET  /api/transactions?agentId=...       recent history (WalletBadge/debug)
"""
from flask import Blueprint, jsonify, request

from services import transaction_service
from services.wallet_service import WalletError

transaction_bp = Blueprint("transactions", __name__, url_prefix="/api/transactions")


@transaction_bp.post("/execute")
@transaction_service.require_idempotency_key
def execute(idempotency_key: str):
    body = request.get_json(silent=True) or {}
    agent_id = body.get("agentId")
    session_id = body.get("sessionId")
    items = body.get("items")

    try:
        response = transaction_service.execute_transaction(
            agent_id=agent_id,
            session_id=session_id,
            items=items,
            idempotency_key=idempotency_key,
            source="api",
        )
    except transaction_service.TransactionError as err:
        return jsonify({"error": err.code, "message": str(err), "data": err.data}), err.http_status
    except WalletError as err:
        return jsonify({"error": err.code, "message": str(err)}), 400

    # 202 Accepted: the OTP path is awaiting human verification (no debit yet).
    status_code = 202 if response.get("status") == "awaiting_otp" else 200
    return jsonify(response), status_code


@transaction_bp.post("/<transaction_id>/verify-otp")
def verify_otp(transaction_id: str):
    body = request.get_json(silent=True) or {}
    otp = body.get("otp")
    session_hint = body.get("sessionId", "")
    if not isinstance(otp, str):
        return jsonify({"error": "INVALID_OTT", "hint": "otp (6-digit string) is required."}), 400

    try:
        response, status_code = transaction_service.verify_otp(transaction_id, otp, session_hint)
    except transaction_service.TransactionError as err:
        return jsonify({"error": err.code, "message": str(err)}), err.http_status
    except WalletError as err:
        return jsonify({"error": err.code, "message": str(err)}), 400

    return jsonify(response), status_code


@transaction_bp.get("")
def list_for_agent():
    agent_id = request.args.get("agentId", "")
    if len(agent_id) < 2:
        return jsonify({"error": "INVALID_AGENT_ID"}), 400
    return jsonify({"transactions": transaction_service.list_transactions(agent_id)})
