"""POST /api/agent/chat — Onyx's entrypoint from the Next.js proxy.

Order of operations (grading criterion): the INTENT audit entry is written and
pushed over the WebSocket BEFORE any LLM or tool call — the timeline shows
intent capture even when the model is slow, rate-limited, or down.
"""
from flask import Blueprint, jsonify, request

from services import conversation_service, llm_orchestrator, transaction_service, wallet_service
from services.audit_service import log_step, serialize

agent_bp = Blueprint("agent", __name__, url_prefix="/api/agent")

MAX_PROMPT_LEN = 2000


@agent_bp.post("/chat")
def chat():
    body = request.get_json(silent=True) or {}
    prompt = body.get("prompt")
    session_id = body.get("sessionId")
    agent_id = body.get("agentId")

    if not isinstance(prompt, str) or not prompt.strip():
        return jsonify({"error": "INVALID_PROMPT", "hint": "prompt (non-empty string) is required."}), 400
    if len(prompt) > MAX_PROMPT_LEN:
        return jsonify({"error": "PROMPT_TOO_LONG", "hint": f"prompt must be <= {MAX_PROMPT_LEN} chars."}), 400
    if not isinstance(session_id, str) or not transaction_service.SESSION_ID_RE.match(session_id):
        return jsonify({"error": "INVALID_SESSION_ID"}), 400
    if not isinstance(agent_id, str) or len(agent_id.strip()) < 2:
        return jsonify({"error": "INVALID_AGENT_ID"}), 400

    agent_id = agent_id.strip()
    prompt = prompt.strip()

    # INTENT FIRST — before any LLM/tool latency or failure.
    log_step(session_id, agent_id, "INTENT", {"prompt": prompt, "source": "onyx"})

    try:
        result = llm_orchestrator.process_user_intent(prompt, session_id, agent_id)
    except llm_orchestrator.LlmNotConfigured as err:
        # The intent was still captured; degrade with a clear message.
        result = {"reply": str(err), "toolCalls": []}
    except Exception as err:  # noqa: BLE001
        return jsonify({"error": "LLM_ORCHESTRATION_FAILED", "message": str(err)}), 500

    return jsonify(
        {
            "reply": result["reply"],
            "toolCalls": result["toolCalls"],
            "sessionId": session_id,
            "agentId": agent_id,
        }
    )


@agent_bp.get("/conversation/<session_id>")
def conversation(session_id: str):
    """Hydration for the chat panel (capped, isolated history)."""
    if not transaction_service.SESSION_ID_RE.match(session_id):
        return jsonify({"error": "INVALID_SESSION_ID"}), 400
    return jsonify({"sessionId": session_id, "messages": conversation_service.get_history(session_id)})


# ---------------------------------------------------------------------------
# Aliases so the Next.js proxy (app/api/agent/[...path]) can reach the whole
# agent-service surface under ONE route prefix — the spec pins the web proxy
# tree to /api/agent/*, so wallet + transaction reads live here too.
# ---------------------------------------------------------------------------


@agent_bp.get("/wallet/<agent_id>")
def wallet_alias(agent_id: str):
    if len(agent_id) < 2 or len(agent_id) > 128:
        return jsonify({"error": "INVALID_AGENT_ID"}), 400
    doc = wallet_service.get_wallet(agent_id)
    if doc is None:
        return jsonify({"error": "WALLET_NOT_FOUND", "agentId": agent_id}), 404
    return jsonify(serialize(doc))


@agent_bp.get("/transactions")
def transactions_alias():
    agent_id = request.args.get("agentId", "")
    if len(agent_id) < 2:
        return jsonify({"error": "INVALID_AGENT_ID"}), 400
    return jsonify({"transactions": transaction_service.list_transactions(agent_id)})
