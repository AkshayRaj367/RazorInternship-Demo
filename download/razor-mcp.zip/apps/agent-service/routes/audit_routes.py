"""GET /api/audit/<sessionId> — the server-side hydration fallback for the
timeline (the primary path is ws-gateway's audit:backlog on room join)."""
from flask import Blueprint, jsonify

from services import transaction_service
from services.audit_service import get_timeline

audit_bp = Blueprint("audit", __name__, url_prefix="/api/audit")


@audit_bp.get("/<session_id>")
def timeline(session_id: str):
    if not transaction_service.SESSION_ID_RE.match(session_id):
        return jsonify({"error": "INVALID_SESSION_ID"}), 400
    return jsonify({"sessionId": session_id, "events": get_timeline(session_id)})
