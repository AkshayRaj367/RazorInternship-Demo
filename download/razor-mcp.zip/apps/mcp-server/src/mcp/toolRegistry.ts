/**
 * MCP tool registry — the JSON-RPC 2.0 dispatch table for POST /mcp.
 *
 * `tools/list`  -> descriptors (name / description / inputSchema)
 * `tools/call`  -> { name, arguments } dispatch to the handler
 * A method string equal to a bare tool name (e.g. "search_catalog") is also
 * accepted for convenience and routed to the same handler.
 *
 * The REST fallback (routes/restRoute.ts) calls these SAME service functions —
 * no duplicated business logic anywhere.
 */
import { MCP_TOOLS } from '@razor-mcp/shared-types';
import type { CatalogItemPublic, CatalogListResponse, CreateOrderResponse, OrderPublic, SearchCatalogArgs, GetItemArgs, CreateOrderArgs, GetOrderStatusArgs } from '@razor-mcp/shared-types';
import { McpError } from './errors';
import { searchCatalogTool } from './tools.searchCatalog';
import { getItemTool } from './tools.getItem';
import { createOrderTool } from './tools.createOrder';
import { getOrderStatusTool } from './tools.getOrderStatus';

export type ToolHandler = (args: Record<string, unknown>) => Promise<unknown>;

export interface McpToolDescriptor {
  name: string;
  description: string;
  inputSchema: Record<string, unknown>;
  handler: ToolHandler;
}

export type { SearchCatalogArgs, GetItemArgs, CreateOrderArgs, GetOrderStatusArgs, CatalogItemPublic, CatalogListResponse, CreateOrderResponse, OrderPublic };

export const TOOL_REGISTRY: Record<string, McpToolDescriptor> = {
  [searchCatalogTool.name]: searchCatalogTool,
  [getItemTool.name]: getItemTool,
  [createOrderTool.name]: createOrderTool,
  [getOrderStatusTool.name]: getOrderStatusTool,
};

export function listTools(): Array<{ name: string; description: string; inputSchema: Record<string, unknown> }> {
  return Object.values(TOOL_REGISTRY).map((t) => ({
    name: t.name,
    description: t.description,
    inputSchema: t.inputSchema,
  }));
}

export function isKnownTool(name: unknown): name is string {
  return typeof name === 'string' && Object.prototype.hasOwnProperty.call(TOOL_REGISTRY, name);
}

export async function callTool(name: string, args: Record<string, unknown> | undefined): Promise<unknown> {
  if (!isKnownTool(name)) {
    throw new McpError(-32601, `METHOD_NOT_FOUND: ${name}`, { knownTools: Object.keys(TOOL_REGISTRY) }, 404);
  }
  return TOOL_REGISTRY[name].handler(args ?? {});
}

export { MCP_TOOLS };
